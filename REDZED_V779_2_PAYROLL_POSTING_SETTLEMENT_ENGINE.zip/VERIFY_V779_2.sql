
select jsonb_build_object(
  'payroll_settlement_link',
    exists(
      select 1
      from information_schema.columns
      where table_schema='public'
        and table_name='rr_monthly_payroll_v779_1'
        and column_name='settlement_id'
    ),

  'corrected_generator_rpc',
    to_regprocedure(
      'public.rr_generate_worker_monthly_payroll_v779_1(uuid,date,text,text)'
    ) is not null,

  'post_rpc',
    to_regprocedure(
      'public.rr_post_monthly_payroll_v779_2(uuid,text)'
    ) is not null,

  'review_rpc',
    to_regprocedure(
      'public.rr_open_payroll_review_v779_2(uuid,text)'
    ) is not null,

  'finalize_rpc',
    to_regprocedure(
      'public.rr_finalize_monthly_payroll_v779_2(uuid,text)'
    ) is not null,

  'payment_rpc',
    to_regprocedure(
      'public.rr_record_monthly_salary_payment_v779_2(uuid,numeric,text)'
    ) is not null,

  'settlement_board',
    to_regclass(
      'public.rr_monthly_payroll_settlement_board_v779_2'
    ) is not null,

  'monthly_cycle_allowed',
    exists(
      select 1
      from pg_constraint c
      join pg_class t on t.oid=c.conrelid
      join pg_namespace n on n.oid=t.relnamespace
      where n.nspname='public'
        and t.relname='rr_worker_settlements_v777_2'
        and pg_get_constraintdef(c.oid) like '%MONTHLY%'
    ),

  'calculated_status_allowed',
    exists(
      select 1
      from pg_constraint c
      join pg_class t on t.oid=c.conrelid
      join pg_namespace n on n.oid=t.relnamespace
      where n.nspname='public'
        and t.relname='rr_worker_settlements_v777_2'
        and pg_get_constraintdef(c.oid) like '%CALCULATED%'
    ),

  'claim_debit_status_allowed',
    exists(
      select 1
      from pg_constraint c
      join pg_class t on t.oid=c.conrelid
      join pg_namespace n on n.oid=t.relnamespace
      where n.nspname='public'
        and t.relname='rr_worker_claims_v777_2'
        and pg_get_constraintdef(c.oid) like '%DEBIT_POSTED%'
    )
) as rr_upm_v779_2_verify;
