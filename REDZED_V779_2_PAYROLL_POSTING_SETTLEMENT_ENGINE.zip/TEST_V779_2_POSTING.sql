
-- ============================================================
-- V779.2 SAFE TEST TEMPLATE
-- Replace UUID/month only after a DRAFT payroll exists.
-- Use TEST mode first.
-- ============================================================

-- 1. View DRAFT payrolls
select
  payroll_id,
  worker_id,
  payroll_month,
  monthly_salary_amount,
  net_extra_work_amount,
  incentive_amount,
  claims_recovery_amount,
  net_payable_salary,
  payroll_status,
  posting_date,
  data_mode
from public.rr_monthly_payroll_v779_1
where data_mode='TEST'
order by created_at desc;

-- 2. Post one DRAFT payroll on/after its posting_date
-- select public.rr_post_monthly_payroll_v779_2(
--   '<PAYROLL_ID>'::uuid,
--   'V779.2 TEST posting'
-- );

-- 3. Finalize
-- select public.rr_finalize_monthly_payroll_v779_2(
--   '<PAYROLL_ID>'::uuid,
--   'V779.2 TEST final approval'
-- );

-- 4. Record payment
-- select public.rr_record_monthly_salary_payment_v779_2(
--   '<PAYROLL_ID>'::uuid,
--   1000,
--   'V779.2 TEST partial payment'
-- );
