REDZED V779.2 — PAYROLL POSTING & SETTLEMENT ENGINE

INSTALL
=======
1. Run REDZED_V779_2_PAYROLL_POSTING_SETTLEMENT_ENGINE.sql
2. Run VERIFY_V779_2.sql
3. Use TEST_V779_2_POSTING.sql only after verification.

FLOW
====
DRAFT
→ POSTED + Settlement CALCULATED
→ UNDER_REVIEW (only when dispute exists)
→ FINAL + Settlement APPROVED
→ PAID when closing balance reaches zero

CLAIMS
======
APPROVED_PENDING_SETTLEMENT
→ DEBIT_POSTED at final approval
→ debit_settlement_id is frozen

ADVANCES / INCENTIVES
=====================
Source applications prevent the same record from being used twice.

SETTLEMENT MAPPING
==================
earnings_amount  = Monthly Salary head
overtime_amount  = Net Extra Work amount at universal minute rate
holiday_amount   = 0 (no multiplier)
incentive_amount = Monthly Incentive
advance_recovery_amount = Advance recovery
approved_claim_debit_amount = Approved claims

PAYMENT
=======
Full and partial payment supported.
Unpaid balance remains closing balance and carries forward.

IMPORTANT
=========
rr_upm_worker_ledger_v726 is a production work/action ledger.
It is not a financial payroll ledger, so V779.2 does not write to it.
The existing rr_worker_settlements_v777_2 is the financial settlement record.
