
-- ============================================================
-- REDZED V779.2 — PAYROLL POSTING & SETTLEMENT ENGINE
--
-- Dependencies:
--   V779.1 Universal Monthly Payroll Core
--   Existing:
--     rr_worker_settlements_v777_2
--     rr_worker_claims_v777_2
--     rr_worker_advances_v777_2
--
-- Verified constraints:
--   cycle_type: MONTHLY allowed
--   settlement_status:
--     OPEN, CALCULATED, APPROVED, PAID, CLOSED, REVERSED, CANCELLED
--   claim_status:
--     APPROVED_PENDING_SETTLEMENT -> DEBIT_POSTED
--
-- Important:
--   rr_upm_worker_ledger_v726 is a production-work ledger view,
--   not a financial salary ledger. It is intentionally not written.
-- ============================================================

begin;

-- ------------------------------------------------------------
-- 1. Add settlement link to monthly payroll snapshot
-- ------------------------------------------------------------
alter table public.rr_monthly_payroll_v779_1
  add column if not exists settlement_id uuid
    references public.rr_worker_settlements_v777_2(settlement_id);

create unique index if not exists rr_monthly_payroll_v779_1_settlement_uq
on public.rr_monthly_payroll_v779_1(settlement_id)
where settlement_id is not null;

-- ------------------------------------------------------------
-- 2. Fix V779.1 payroll generation to use exact verified claim status
-- ------------------------------------------------------------
create or replace function public.rr_generate_worker_monthly_payroll_v779_1(
  p_worker_id uuid,
  p_payroll_month date,
  p_data_mode text default 'TEST',
  p_reason text default null
)
returns jsonb
language plpgsql
security definer
set search_path='public'
as $$
declare
  v_mode text:=upper(trim(coalesce(p_data_mode,'TEST')));
  v_period_start date;
  v_period_end date;
  v_posting_date date;
  v_review_from date;
  v_review_until date;

  v_profile public.rr_worker_payroll_profile_v777_2%rowtype;

  v_scheduled integer:=0;
  v_deduction integer:=0;
  v_extra integer:=0;
  v_working integer:=0;

  v_incentive numeric:=0;
  v_claim numeric:=0;
  v_advance numeric:=0;
  v_recovery numeric:=0;

  v_calc jsonb;
  v_payroll_id uuid;
  v_old jsonb;
  v_new jsonb;
begin
  if not public.rr_payroll_can_manage_v779_1() then
    raise exception 'Payroll generation permission denied.';
  end if;

  if date_trunc('month',p_payroll_month)::date<>p_payroll_month then
    raise exception 'Payroll Month first date honi chahiye.';
  end if;

  v_period_start:=p_payroll_month;
  v_period_end:=(p_payroll_month+interval '1 month-1 day')::date;
  v_posting_date:=(p_payroll_month+interval '1 month')::date;
  v_review_from:=v_posting_date+1;
  v_review_until:=v_posting_date+6;

  select *
  into v_profile
  from public.rr_active_payroll_profile_v778_2(
    p_worker_id,v_period_end,v_mode
  );

  if v_profile.profile_id is null then
    raise exception 'Active Payroll Profile required hai.';
  end if;

  if upper(v_profile.worker_category)<>'SALARIED' then
    raise exception 'Monthly payroll SALARIED Worker ke liye hai.';
  end if;

  select
    coalesce(sum(scheduled_payable_minutes),0)::integer,
    coalesce(sum(net_deduction_minutes),0)::integer,
    coalesce(sum(net_extra_work_minutes),0)::integer,
    coalesce(sum(net_working_minutes),0)::integer
  into v_scheduled,v_deduction,v_extra,v_working
  from public.rr_attendance_day_v777_2
  where worker_id=p_worker_id
    and attendance_date between v_period_start and v_period_end
    and data_mode=v_mode
    and approval_status='APPROVED';

  select coalesce(sum(i.incentive_amount),0)
  into v_incentive
  from public.rr_payroll_incentives_v779_1 i
  where i.worker_id=p_worker_id
    and i.payroll_month=p_payroll_month
    and i.data_mode=v_mode
    and i.incentive_status='APPROVED'
    and not exists(
      select 1
      from public.rr_payroll_source_applications_v779_1 a
      where a.source_type='INCENTIVE'
        and a.source_id=i.incentive_id
        and a.data_mode=v_mode
        and a.reversed_at is null
    );

  select coalesce(sum(c.approved_amount),0)
  into v_claim
  from public.rr_worker_claims_v777_2 c
  where c.worker_id=p_worker_id
    and c.data_mode=v_mode
    and c.claim_status='APPROVED_PENDING_SETTLEMENT'
    and c.reversed_at is null
    and c.approved_amount>0
    and not exists(
      select 1
      from public.rr_payroll_source_applications_v779_1 a
      where a.source_type='CLAIM'
        and a.source_id=c.claim_id
        and a.data_mode=v_mode
        and a.reversed_at is null
    );

  select coalesce(sum(a.advance_amount),0)
  into v_advance
  from public.rr_worker_advances_v777_2 a
  where a.worker_id=p_worker_id
    and a.data_mode=v_mode
    and not a.is_reversed
    and a.advance_date<=v_period_end
    and not exists(
      select 1
      from public.rr_payroll_source_applications_v779_1 x
      where x.source_type='ADVANCE'
        and x.source_id=a.advance_id
        and x.data_mode=v_mode
        and x.reversed_at is null
    );

  v_recovery:=v_claim+v_advance;

  v_calc:=public.rr_calculate_monthly_salary_v779_1(
    v_profile.monthly_salary,
    v_deduction,
    v_extra,
    v_incentive,
    v_recovery
  );

  select to_jsonb(p)
  into v_old
  from public.rr_monthly_payroll_v779_1 p
  where p.worker_id=p_worker_id
    and p.payroll_month=p_payroll_month
    and p.data_mode=v_mode;

  insert into public.rr_monthly_payroll_v779_1(
    worker_id,payroll_month,worker_category,profile_id,
    monthly_salary_contract,
    scheduled_minutes_snapshot,
    net_deduction_minutes,
    net_extra_work_minutes,
    net_working_minutes,
    per_minute_rate,
    deduction_amount,
    monthly_salary_amount,
    net_extra_work_amount,
    incentive_amount,
    approved_claim_amount,
    advance_recovery_amount,
    claims_recovery_amount,
    net_payable_salary,
    payroll_status,
    posting_date,review_from,review_until,
    calculation_snapshot,
    data_mode,created_by,updated_at
  )
  values(
    p_worker_id,p_payroll_month,'SALARIED',v_profile.profile_id,
    v_profile.monthly_salary,
    v_scheduled,v_deduction,v_extra,v_working,
    (v_calc->>'per_minute_rate')::numeric,
    (v_calc->>'deduction_amount')::numeric,
    (v_calc->>'monthly_salary_amount')::numeric,
    (v_calc->>'net_extra_work_amount')::numeric,
    v_incentive,v_claim,v_advance,v_recovery,
    (v_calc->>'net_payable_salary')::numeric,
    'DRAFT',
    v_posting_date,v_review_from,v_review_until,
    jsonb_build_object(
      'engine_version','V779_2_PAYROLL_POSTING_SETTLEMENT_ENGINE',
      'period_start',v_period_start,
      'period_end',v_period_end,
      'profile_snapshot',to_jsonb(v_profile),
      'attendance',jsonb_build_object(
        'scheduled_minutes',v_scheduled,
        'net_deduction_minutes',v_deduction,
        'net_extra_work_minutes',v_extra,
        'net_working_minutes',v_working,
        'net_deduction_dhm',public.rr_minutes_dhm_v778_2(v_deduction),
        'net_extra_work_dhm',public.rr_minutes_dhm_v778_2(v_extra)
      ),
      'calculator',v_calc,
      'claims_amount',v_claim,
      'advance_recovery_amount',v_advance,
      'incentive_amount',v_incentive,
      'reason',p_reason
    ),
    v_mode,auth.uid(),now()
  )
  on conflict(worker_id,payroll_month,data_mode) do update set
    profile_id=excluded.profile_id,
    monthly_salary_contract=excluded.monthly_salary_contract,
    scheduled_minutes_snapshot=excluded.scheduled_minutes_snapshot,
    net_deduction_minutes=excluded.net_deduction_minutes,
    net_extra_work_minutes=excluded.net_extra_work_minutes,
    net_working_minutes=excluded.net_working_minutes,
    per_minute_rate=excluded.per_minute_rate,
    deduction_amount=excluded.deduction_amount,
    monthly_salary_amount=excluded.monthly_salary_amount,
    net_extra_work_amount=excluded.net_extra_work_amount,
    incentive_amount=excluded.incentive_amount,
    approved_claim_amount=excluded.approved_claim_amount,
    advance_recovery_amount=excluded.advance_recovery_amount,
    claims_recovery_amount=excluded.claims_recovery_amount,
    net_payable_salary=excluded.net_payable_salary,
    posting_date=excluded.posting_date,
    review_from=excluded.review_from,
    review_until=excluded.review_until,
    calculation_snapshot=excluded.calculation_snapshot,
    updated_at=now()
  where public.rr_monthly_payroll_v779_1.payroll_status
    in('DRAFT','UNDER_REVIEW')
  returning payroll_id into v_payroll_id;

  if v_payroll_id is null then
    raise exception 'POSTED/FINAL/PAID payroll refresh nahi ho sakta.';
  end if;

  select to_jsonb(p)
  into v_new
  from public.rr_monthly_payroll_v779_1 p
  where p.payroll_id=v_payroll_id;

  insert into public.rr_payroll_events_v779_1(
    payroll_id,worker_id,payroll_month,event_type,
    old_snapshot,new_snapshot,reason,data_mode
  )
  values(
    v_payroll_id,p_worker_id,p_payroll_month,
    case when v_old is null then 'PAYROLL_GENERATED'
         else 'PAYROLL_RECALCULATED' end,
    v_old,v_new,p_reason,v_mode
  );

  return jsonb_build_object(
    'ok',true,
    'version','V779_2_PAYROLL_POSTING_SETTLEMENT_ENGINE',
    'payroll_id',v_payroll_id,
    'worker_id',p_worker_id,
    'payroll_month',p_payroll_month,
    'monthly_salary',(v_calc->>'monthly_salary_amount')::numeric,
    'net_extra_work_amount',(v_calc->>'net_extra_work_amount')::numeric,
    'net_extra_work_dhm',public.rr_minutes_dhm_v778_2(v_extra),
    'monthly_incentive',v_incentive,
    'claims_recovery',v_recovery,
    'net_payable_salary',(v_calc->>'net_payable_salary')::numeric,
    'status','DRAFT'
  );
end $$;

-- ------------------------------------------------------------
-- 3. Post payroll on/after the 1st of next month
--
-- Creates CALCULATED settlement.
-- Does not consume claims/advances until FINAL approval.
-- ------------------------------------------------------------
create or replace function public.rr_post_monthly_payroll_v779_2(
  p_payroll_id uuid,
  p_reason text default null
)
returns jsonb
language plpgsql
security definer
set search_path='public'
as $$
declare
  v_payroll public.rr_monthly_payroll_v779_1%rowtype;
  v_settlement_id uuid;
  v_opening numeric:=0;
  v_closing numeric:=0;
  v_old jsonb;
  v_new jsonb;
begin
  if not public.rr_payroll_can_manage_v779_1() then
    raise exception 'Payroll posting permission denied.';
  end if;

  select *
  into v_payroll
  from public.rr_monthly_payroll_v779_1
  where payroll_id=p_payroll_id
  for update;

  if not found then raise exception 'Payroll record nahi mila.'; end if;

  if v_payroll.payroll_status<>'DRAFT' then
    raise exception 'Sirf DRAFT payroll post ho sakta hai.';
  end if;

  if current_date<v_payroll.posting_date then
    raise exception 'Salary posting date % hai.',v_payroll.posting_date;
  end if;

  select coalesce(s.closing_balance,0)
  into v_opening
  from public.rr_worker_settlements_v777_2 s
  where s.worker_id=v_payroll.worker_id
    and s.data_mode=v_payroll.data_mode
    and s.settlement_status not in('REVERSED','CANCELLED')
    and s.period_end<v_payroll.payroll_month
  order by s.period_end desc,s.created_at desc
  limit 1;

  v_opening:=coalesce(v_opening,0);

  -- payment_amount is zero until actual payment.
  v_closing:=
      v_opening
    + v_payroll.monthly_salary_amount
    + v_payroll.incentive_amount
    + v_payroll.net_extra_work_amount
    - v_payroll.advance_recovery_amount
    - v_payroll.approved_claim_amount;

  insert into public.rr_worker_settlements_v777_2(
    worker_id,worker_category,cycle_type,
    period_start,period_end,
    opening_balance,
    earnings_amount,
    incentive_amount,
    overtime_amount,
    holiday_amount,
    advance_recovery_amount,
    approved_claim_debit_amount,
    payment_amount,
    closing_balance,
    claim_debit_applied,
    full_and_final,
    settlement_status,
    calculation_snapshot,
    data_mode,created_by
  )
  values(
    v_payroll.worker_id,'SALARIED','MONTHLY',
    v_payroll.payroll_month,
    (v_payroll.payroll_month+interval '1 month-1 day')::date,
    v_opening,
    v_payroll.monthly_salary_amount,
    v_payroll.incentive_amount,
    v_payroll.net_extra_work_amount,
    0,
    v_payroll.advance_recovery_amount,
    v_payroll.approved_claim_amount,
    0,
    v_closing,
    false,
    false,
    'CALCULATED',
    jsonb_build_object(
      'engine_version','V779_2_PAYROLL_POSTING_SETTLEMENT_ENGINE',
      'payroll_id',v_payroll.payroll_id,
      'monthly_salary_head',v_payroll.monthly_salary_amount,
      'net_extra_work_head',v_payroll.net_extra_work_amount,
      'monthly_incentive_head',v_payroll.incentive_amount,
      'claims_recovery_head',v_payroll.claims_recovery_amount,
      'net_payable_salary',v_payroll.net_payable_salary,
      'legacy_column_mapping',jsonb_build_object(
        'earnings_amount','MONTHLY_SALARY',
        'overtime_amount','NET_EXTRA_WORK_AT_UNIVERSAL_MINUTE_RATE',
        'holiday_amount','ZERO_NO_MULTIPLIER'
      )
    ),
    v_payroll.data_mode,auth.uid()
  )
  on conflict(worker_id,cycle_type,period_start,period_end,data_mode)
  do update set
    opening_balance=excluded.opening_balance,
    earnings_amount=excluded.earnings_amount,
    incentive_amount=excluded.incentive_amount,
    overtime_amount=excluded.overtime_amount,
    holiday_amount=0,
    advance_recovery_amount=excluded.advance_recovery_amount,
    approved_claim_debit_amount=excluded.approved_claim_debit_amount,
    payment_amount=0,
    closing_balance=excluded.closing_balance,
    claim_debit_applied=false,
    settlement_status='CALCULATED',
    calculation_snapshot=excluded.calculation_snapshot
  where public.rr_worker_settlements_v777_2.settlement_status
    in('OPEN','CALCULATED')
  returning settlement_id into v_settlement_id;

  if v_settlement_id is null then
    raise exception 'Existing settlement already approved/closed hai.';
  end if;

  v_old:=to_jsonb(v_payroll);

  update public.rr_monthly_payroll_v779_1
  set payroll_status='POSTED',
      settlement_id=v_settlement_id,
      updated_at=now()
  where payroll_id=p_payroll_id
  returning to_jsonb(rr_monthly_payroll_v779_1.*) into v_new;

  insert into public.rr_payroll_events_v779_1(
    payroll_id,worker_id,payroll_month,event_type,
    old_snapshot,new_snapshot,reason,data_mode
  )
  values(
    p_payroll_id,v_payroll.worker_id,v_payroll.payroll_month,
    'PAYROLL_POSTED',v_old,v_new,p_reason,v_payroll.data_mode
  );

  return jsonb_build_object(
    'ok',true,
    'version','V779_2_PAYROLL_POSTING_SETTLEMENT_ENGINE',
    'payroll_id',p_payroll_id,
    'settlement_id',v_settlement_id,
    'payroll_status','POSTED',
    'settlement_status','CALCULATED',
    'opening_balance',v_opening,
    'net_payable_salary',v_payroll.net_payable_salary,
    'closing_balance',v_closing
  );
end $$;

-- ------------------------------------------------------------
-- 4. Put posted payroll under review
-- ------------------------------------------------------------
create or replace function public.rr_open_payroll_review_v779_2(
  p_payroll_id uuid,
  p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path='public'
as $$
declare
  v_payroll public.rr_monthly_payroll_v779_1%rowtype;
begin
  if not public.rr_payroll_can_manage_v779_1() then
    raise exception 'Payroll review permission denied.';
  end if;

  select *
  into v_payroll
  from public.rr_monthly_payroll_v779_1
  where payroll_id=p_payroll_id
  for update;

  if not found then raise exception 'Payroll nahi mila.'; end if;

  if v_payroll.payroll_status<>'POSTED' then
    raise exception 'Sirf POSTED payroll review me ja sakta hai.';
  end if;

  update public.rr_monthly_payroll_v779_1
  set payroll_status='UNDER_REVIEW',updated_at=now()
  where payroll_id=p_payroll_id;

  insert into public.rr_payroll_events_v779_1(
    payroll_id,worker_id,payroll_month,event_type,
    old_snapshot,new_snapshot,reason,data_mode
  )
  values(
    p_payroll_id,v_payroll.worker_id,v_payroll.payroll_month,
    'REVIEW_OPENED',to_jsonb(v_payroll),
    jsonb_build_object('status','UNDER_REVIEW'),
    p_reason,v_payroll.data_mode
  );

  return jsonb_build_object(
    'ok',true,'payroll_id',p_payroll_id,'status','UNDER_REVIEW'
  );
end $$;

-- ------------------------------------------------------------
-- 5. Finalize payroll
--
-- Owner/Admin only.
-- Consumes approved claims, advances and incentives exactly once.
-- ------------------------------------------------------------
create or replace function public.rr_finalize_monthly_payroll_v779_2(
  p_payroll_id uuid,
  p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path='public'
as $$
declare
  v_payroll public.rr_monthly_payroll_v779_1%rowtype;
  v_settlement public.rr_worker_settlements_v777_2%rowtype;
  v_claim record;
  v_advance record;
  v_incentive record;
begin
  if public.rr_payroll_actor_role_v779_1() not in('owner','admin') then
    raise exception 'Final settlement Owner/Admin only.';
  end if;

  select *
  into v_payroll
  from public.rr_monthly_payroll_v779_1
  where payroll_id=p_payroll_id
  for update;

  if not found then raise exception 'Payroll nahi mila.'; end if;

  if v_payroll.payroll_status not in('POSTED','UNDER_REVIEW') then
    raise exception 'Payroll POSTED/UNDER_REVIEW hona chahiye.';
  end if;

  if v_payroll.settlement_id is null then
    raise exception 'Settlement link missing hai.';
  end if;

  select *
  into v_settlement
  from public.rr_worker_settlements_v777_2
  where settlement_id=v_payroll.settlement_id
  for update;

  if not found or v_settlement.settlement_status<>'CALCULATED' then
    raise exception 'CALCULATED settlement required hai.';
  end if;

  -- Claims: exact status and settlement link.
  for v_claim in
    select c.*
    from public.rr_worker_claims_v777_2 c
    where c.worker_id=v_payroll.worker_id
      and c.data_mode=v_payroll.data_mode
      and c.claim_status='APPROVED_PENDING_SETTLEMENT'
      and c.reversed_at is null
      and c.approved_amount>0
      and not exists(
        select 1
        from public.rr_payroll_source_applications_v779_1 a
        where a.source_type='CLAIM'
          and a.source_id=c.claim_id
          and a.data_mode=v_payroll.data_mode
          and a.reversed_at is null
      )
    for update
  loop
    insert into public.rr_payroll_source_applications_v779_1(
      payroll_id,worker_id,source_type,source_id,
      applied_amount,data_mode,applied_by
    )
    values(
      p_payroll_id,v_payroll.worker_id,'CLAIM',v_claim.claim_id,
      v_claim.approved_amount,v_payroll.data_mode,auth.uid()
    );

    update public.rr_worker_claims_v777_2
    set claim_status='DEBIT_POSTED',
        debit_settlement_id=v_payroll.settlement_id,
        debit_posted_at=now()
    where claim_id=v_claim.claim_id;
  end loop;

  -- Advances: source application prevents reuse.
  for v_advance in
    select a.*
    from public.rr_worker_advances_v777_2 a
    where a.worker_id=v_payroll.worker_id
      and a.data_mode=v_payroll.data_mode
      and not a.is_reversed
      and a.advance_date<=(
        v_payroll.payroll_month+interval '1 month-1 day'
      )::date
      and not exists(
        select 1
        from public.rr_payroll_source_applications_v779_1 x
        where x.source_type='ADVANCE'
          and x.source_id=a.advance_id
          and x.data_mode=v_payroll.data_mode
          and x.reversed_at is null
      )
    for update
  loop
    insert into public.rr_payroll_source_applications_v779_1(
      payroll_id,worker_id,source_type,source_id,
      applied_amount,data_mode,applied_by
    )
    values(
      p_payroll_id,v_payroll.worker_id,'ADVANCE',v_advance.advance_id,
      v_advance.advance_amount,v_payroll.data_mode,auth.uid()
    );
  end loop;

  -- Approved incentives: consume exactly once.
  for v_incentive in
    select i.*
    from public.rr_payroll_incentives_v779_1 i
    where i.worker_id=v_payroll.worker_id
      and i.payroll_month=v_payroll.payroll_month
      and i.data_mode=v_payroll.data_mode
      and i.incentive_status='APPROVED'
      and not exists(
        select 1
        from public.rr_payroll_source_applications_v779_1 x
        where x.source_type='INCENTIVE'
          and x.source_id=i.incentive_id
          and x.data_mode=v_payroll.data_mode
          and x.reversed_at is null
      )
    for update
  loop
    insert into public.rr_payroll_source_applications_v779_1(
      payroll_id,worker_id,source_type,source_id,
      applied_amount,data_mode,applied_by
    )
    values(
      p_payroll_id,v_payroll.worker_id,'INCENTIVE',
      v_incentive.incentive_id,v_incentive.incentive_amount,
      v_payroll.data_mode,auth.uid()
    );
  end loop;

  update public.rr_worker_settlements_v777_2
  set settlement_status='APPROVED',
      claim_debit_applied=
        (v_payroll.approved_claim_amount>0),
      approved_at=now(),
      approved_by=auth.uid()
  where settlement_id=v_payroll.settlement_id;

  update public.rr_monthly_payroll_v779_1
  set payroll_status='FINAL',
      finalized_at=now(),
      finalized_by=auth.uid(),
      updated_at=now()
  where payroll_id=p_payroll_id;

  insert into public.rr_payroll_events_v779_1(
    payroll_id,worker_id,payroll_month,event_type,
    old_snapshot,new_snapshot,reason,data_mode
  )
  values(
    p_payroll_id,v_payroll.worker_id,v_payroll.payroll_month,
    'PAYROLL_FINALIZED',to_jsonb(v_payroll),
    jsonb_build_object(
      'payroll_status','FINAL',
      'settlement_status','APPROVED',
      'settlement_id',v_payroll.settlement_id
    ),
    p_reason,v_payroll.data_mode
  );

  return jsonb_build_object(
    'ok',true,
    'version','V779_2_PAYROLL_POSTING_SETTLEMENT_ENGINE',
    'payroll_id',p_payroll_id,
    'settlement_id',v_payroll.settlement_id,
    'payroll_status','FINAL',
    'settlement_status','APPROVED',
    'net_payable_salary',v_payroll.net_payable_salary
  );
end $$;

-- ------------------------------------------------------------
-- 6. Record salary payment
--
-- Supports full or partial payment.
-- Settlement closing balance remains unpaid carry-forward.
-- ------------------------------------------------------------
create or replace function public.rr_record_monthly_salary_payment_v779_2(
  p_payroll_id uuid,
  p_payment_amount numeric,
  p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path='public'
as $$
declare
  v_payroll public.rr_monthly_payroll_v779_1%rowtype;
  v_settlement public.rr_worker_settlements_v777_2%rowtype;
  v_new_paid numeric;
  v_new_closing numeric;
  v_status text;
begin
  if public.rr_payroll_actor_role_v779_1() not in('owner','admin') then
    raise exception 'Salary payment Owner/Admin only.';
  end if;

  if coalesce(p_payment_amount,0)<=0 then
    raise exception 'Payment amount positive hona chahiye.';
  end if;

  select *
  into v_payroll
  from public.rr_monthly_payroll_v779_1
  where payroll_id=p_payroll_id
  for update;

  if not found or v_payroll.payroll_status not in('FINAL','PAID') then
    raise exception 'FINAL payroll required hai.';
  end if;

  select *
  into v_settlement
  from public.rr_worker_settlements_v777_2
  where settlement_id=v_payroll.settlement_id
  for update;

  if not found or v_settlement.settlement_status not in('APPROVED','PAID') then
    raise exception 'APPROVED settlement required hai.';
  end if;

  v_new_paid:=v_settlement.payment_amount+p_payment_amount;

  if v_new_paid>v_settlement.opening_balance
      +v_settlement.earnings_amount
      +v_settlement.incentive_amount
      +v_settlement.overtime_amount
      +v_settlement.holiday_amount
      -v_settlement.advance_recovery_amount
      -v_settlement.approved_claim_debit_amount
  then
    raise exception 'Payment payable balance se zyada hai.';
  end if;

  v_new_closing:=
      v_settlement.opening_balance
    + v_settlement.earnings_amount
    + v_settlement.incentive_amount
    + v_settlement.overtime_amount
    + v_settlement.holiday_amount
    - v_settlement.advance_recovery_amount
    - v_settlement.approved_claim_debit_amount
    - v_new_paid;

  v_status:=case when v_new_closing=0 then 'PAID' else 'APPROVED' end;

  update public.rr_worker_settlements_v777_2
  set payment_amount=v_new_paid,
      closing_balance=v_new_closing,
      settlement_status=v_status,
      closed_at=case when v_new_closing=0 then now() else closed_at end
  where settlement_id=v_payroll.settlement_id;

  update public.rr_monthly_payroll_v779_1
  set payroll_status=case when v_new_closing=0 then 'PAID' else 'FINAL' end,
      updated_at=now()
  where payroll_id=p_payroll_id;

  insert into public.rr_payroll_events_v779_1(
    payroll_id,worker_id,payroll_month,event_type,
    old_snapshot,new_snapshot,reason,data_mode
  )
  values(
    p_payroll_id,v_payroll.worker_id,v_payroll.payroll_month,
    'SALARY_PAYMENT_RECORDED',
    to_jsonb(v_settlement),
    jsonb_build_object(
      'payment_added',p_payment_amount,
      'total_payment',v_new_paid,
      'closing_balance',v_new_closing,
      'settlement_status',v_status
    ),
    p_reason,v_payroll.data_mode
  );

  return jsonb_build_object(
    'ok',true,
    'payroll_id',p_payroll_id,
    'settlement_id',v_payroll.settlement_id,
    'payment_added',p_payment_amount,
    'total_payment',v_new_paid,
    'closing_balance',v_new_closing,
    'payroll_status',case when v_new_closing=0 then 'PAID' else 'FINAL' end,
    'settlement_status',v_status
  );
end $$;

-- ------------------------------------------------------------
-- 7. Payroll + settlement read board
-- ------------------------------------------------------------
drop view if exists public.rr_monthly_payroll_settlement_board_v779_2;

create view public.rr_monthly_payroll_settlement_board_v779_2 as
select
  p.payroll_id,
  p.worker_id,
  w.worker_code,
  w.worker_name,
  w.department_code,
  p.payroll_month,

  p.monthly_salary_amount,
  p.net_extra_work_amount,
  public.rr_minutes_dhm_v778_2(p.net_extra_work_minutes)
    as net_extra_work_dhm,
  p.incentive_amount,
  p.claims_recovery_amount,
  p.net_payable_salary,

  p.payroll_status,
  p.settlement_id,

  s.settlement_status,
  s.opening_balance,
  s.payment_amount,
  s.closing_balance,

  p.posting_date,
  p.review_from,
  p.review_until,
  p.data_mode
from public.rr_monthly_payroll_v779_1 p
join public.rr_worker_directory_unified_v1 w
  on w.worker_id=p.worker_id
left join public.rr_worker_settlements_v777_2 s
  on s.settlement_id=p.settlement_id;

-- ------------------------------------------------------------
-- 8. Grants
-- ------------------------------------------------------------
grant execute on function public.rr_post_monthly_payroll_v779_2(
  uuid,text
) to authenticated;

grant execute on function public.rr_open_payroll_review_v779_2(
  uuid,text
) to authenticated;

grant execute on function public.rr_finalize_monthly_payroll_v779_2(
  uuid,text
) to authenticated;

grant execute on function public.rr_record_monthly_salary_payment_v779_2(
  uuid,numeric,text
) to authenticated;

revoke all on public.rr_monthly_payroll_settlement_board_v779_2
from anon,authenticated;

commit;

select jsonb_build_object(
  'ok',true,
  'version','V779_2_PAYROLL_POSTING_SETTLEMENT_ENGINE',

  'posting_flow',jsonb_build_array(
    'DRAFT',
    'POSTED_CALCULATED',
    'UNDER_REVIEW_OPTIONAL',
    'FINAL_APPROVED',
    'PAID'
  ),

  'salary_posting_day',1,
  'review_window','2_TO_7',
  'final_authority',jsonb_build_array('OWNER','ADMIN'),

  'existing_settlement_reused',true,
  'existing_claims_reused',true,
  'existing_advances_reused',true,

  'claim_status_transition',
    'APPROVED_PENDING_SETTLEMENT_TO_DEBIT_POSTED',

  'double_source_application_protection',true,
  'partial_payment_supported',true,
  'carry_forward_supported',true,

  'production_worker_ledger_written',false,
  'reason',
    'RR_UPM_WORKER_LEDGER_V726_IS_PRODUCTION_WORK_LEDGER_NOT_FINANCIAL_LEDGER'
) as rr_upm_v779_2_result;
