
select jsonb_build_object(
  'generation_mode_column',exists(
    select 1 from information_schema.columns
    where table_schema='public'
      and table_name='rr_monthly_payroll_v779_1'
      and column_name='generation_mode'
  ),
  'legacy_reason_column',exists(
    select 1 from information_schema.columns
    where table_schema='public'
      and table_name='rr_monthly_payroll_v779_1'
      and column_name='legacy_reason'
  ),
  'classification_rpc',to_regprocedure(
    'public.rr_worker_payment_classification_v779_5(uuid,date,text)'
  ) is not null,
  'earning_guard_rpc',to_regprocedure(
    'public.rr_assert_worker_earning_type_v779_5(uuid,text,date,text)'
  ) is not null,
  'attendance_generate_rpc',to_regprocedure(
    'public.rr_generate_worker_monthly_payroll_safe_v779_5(uuid,date,text,text)'
  ) is not null,
  'legacy_generate_rpc',to_regprocedure(
    'public.rr_generate_worker_monthly_payroll_legacy_v779_5(uuid,date,text,text)'
  ) is not null,
  'attendance_batch_rpc',to_regprocedure(
    'public.rr_generate_monthly_payroll_batch_v779_5(date,text,text)'
  ) is not null,
  'legacy_batch_rpc',to_regprocedure(
    'public.rr_generate_monthly_payroll_legacy_batch_v779_5(date,text,text)'
  ) is not null,
  'management_board_rpc',to_regprocedure(
    'public.rr_get_payroll_management_board_v779_5(date,text)'
  ) is not null
) as rr_upm_v779_5_verify;
