REDZED V779.5 MONTHLY SALARY FINAL LOCK

DO NOT RUN the earlier V779.4 generation-fix SQL.
Run only:
1. REDZED_V779_5_MONTHLY_SALARY_FINAL_LOCK.sql
2. VERIFY_V779_5.sql
3. Upload/replace real-monthly-payroll-v779.js
4. Ctrl + Shift + R

Legacy:
- Owner/Admin only
- completed historical month
- no approved attendance
- mandatory reason
- full monthly contract salary
- marked LEGACY_GENERATED

Classification:
- SALARIED remains SALARIED across all secondary departments
- SALARIED never receives PCS pay
- department Actual Rate remains lot/process costing
- PIECE_RATE module will be built next, including ₹15,000/18,000-minute support incentive
