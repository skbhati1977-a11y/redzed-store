REDZED FULL MATCHING V39 — UPLOAD ORDER

1) SUPABASE
   SQL Editor me ek NEW query kholiye.
   REDZED-MATCHING-CLOTH-V39.sql ka poora code paste karke RUN kijiye.
   V38 migration dobara run nahi karni.

2) GITHUB ROOT / redzed-store FOLDER ME REPLACE/UPLOAD
   - real-product-master-final.html
   - real-product-master-final-v718.js
   - real-cutting-master-final.html
   - real-cutting-master-pm.js

3) GitHub Pages deploy complete hone ke baad hard reload:
   Windows: Ctrl + Shift + R
   Mobile Chrome: Site settings > Clear & reset, phir page reopen.

LOCKED LOGIC
- First purchase Regular Cloth hard-lock removed.
- New CB first purchase Regular Cloth ya Matching Cloth dono ho sakti hai.
- Matching Cloth Product Master purchase automatic stock ledger me jayegi.
- Cutting release par Matching Qty stock se deduct hogi.
- Backend current weighted average rate snapshot karega.
- Matching cost Art-driven final per-piece costing me add hogi.
- Purane released lots ka snapshot future purchase se change nahi hoga.

IMPORTANT
- Product Master HTML ab real-product-master-final-v718.js?v=7180 load karti hai.
- Ye package active v715B loader structure ke liye banaya gaya hai.
