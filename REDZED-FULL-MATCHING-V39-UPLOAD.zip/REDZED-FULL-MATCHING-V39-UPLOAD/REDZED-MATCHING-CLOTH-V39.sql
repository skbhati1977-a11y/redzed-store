-- REDZED REAL — MATCHING CLOTH STOCK + CUTTING COST V39
-- Run once in a NEW Supabase SQL Editor query.
-- Safe/idempotent: creates stock ledger, imports old matching purchases once,
-- and adds V4 Single/Multi release RPCs. Existing Lots are not deleted.

begin;

create extension if not exists pgcrypto;

-- ---------------------------------------------------------
-- 0. GUARDS
-- ---------------------------------------------------------
do $guard$
begin
  if to_regclass('public.rr_material_categories') is null then
    raise exception 'Missing public.rr_material_categories';
  end if;
  if to_regclass('public.rr_cb_purchase_entries') is null then
    raise exception 'Missing public.rr_cb_purchase_entries';
  end if;
  if to_regclass('public.rr_cutting_lots_v3') is null then
    raise exception 'Missing public.rr_cutting_lots_v3';
  end if;
  if to_regclass('public.rr_production_lots') is null then
    raise exception 'Missing public.rr_production_lots';
  end if;
  if to_regprocedure('public.rr_release_single_lot_v3(text,uuid,date,text,text,text,text,text[],integer,numeric,numeric,numeric,numeric,text,text,text,numeric,text,jsonb)') is null then
    raise exception 'Missing public.rr_release_single_lot_v3';
  end if;
  if to_regprocedure('public.rr_release_multi_lots_v3(uuid,date,text,text,text,text,numeric,numeric,numeric,numeric,text,jsonb)') is null then
    raise exception 'Missing public.rr_release_multi_lots_v3. Run V38 migration first.';
  end if;
end
$guard$;

insert into public.rr_material_categories
  (category_code, category_name, unit, sort_order, is_active)
values
  ('matching-cloth', 'Matching Cloth', 'kg', 30, true)
on conflict (category_code) do update
set category_name = excluded.category_name,
    unit = excluded.unit,
    sort_order = excluded.sort_order,
    is_active = true;

-- ---------------------------------------------------------
-- 1. GLOBAL MATCHING CLOTH STOCK LEDGER
-- ---------------------------------------------------------
create table if not exists public.rr_matching_cloth_items_v1 (
  id uuid primary key default gen_random_uuid(),
  fabric_name text not null,
  stock_qty numeric(14,3) not null default 0 check (stock_qty >= 0),
  stock_value numeric(16,2) not null default 0 check (stock_value >= 0),
  avg_cost numeric(14,4) not null default 0 check (avg_cost >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists rr_matching_cloth_items_name_uq
  on public.rr_matching_cloth_items_v1 (lower(btrim(fabric_name)));

create table if not exists public.rr_matching_cloth_purchases_v1 (
  id uuid primary key default gen_random_uuid(),
  matching_item_id uuid not null
    references public.rr_matching_cloth_items_v1(id) on delete restrict,
  vendor_name text,
  vendor_bill_no text,
  bill_date date not null default current_date,
  quantity numeric(14,3) not null check (quantity > 0),
  rate numeric(14,4) not null check (rate > 0),
  amount numeric(16,2)
    generated always as (round(quantity * rate, 2)) stored,
  notes text,
  source_purchase_entry_id uuid,
  purchased_at timestamptz not null default now(),
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);

create unique index if not exists rr_matching_purchase_source_uq
  on public.rr_matching_cloth_purchases_v1(source_purchase_entry_id)
  where source_purchase_entry_id is not null;

create index if not exists rr_matching_purchase_item_time_idx
  on public.rr_matching_cloth_purchases_v1(matching_item_id, purchased_at, id);

create table if not exists public.rr_matching_cloth_consumptions_v1 (
  id uuid primary key default gen_random_uuid(),
  matching_item_id uuid not null
    references public.rr_matching_cloth_items_v1(id) on delete restrict,
  cb_unit_id uuid not null
    references public.rr_cb_units(id) on delete restrict,
  lot_kind text not null check (lot_kind in ('single','multi')),
  cutting_lot_id uuid
    references public.rr_cutting_lots_v3(id) on delete restrict,
  production_lot_id uuid
    references public.rr_production_lots(id) on delete restrict,
  lot_no_snapshot text not null,
  quantity numeric(14,3) not null check (quantity > 0),
  avg_cost_snapshot numeric(14,4) not null check (avg_cost_snapshot >= 0),
  amount numeric(16,2)
    generated always as (round(quantity * avg_cost_snapshot, 2)) stored,
  consumed_at timestamptz not null default now(),
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  constraint rr_matching_consumption_lot_chk check (
    (lot_kind = 'single' and cutting_lot_id is not null and production_lot_id is null)
    or
    (lot_kind = 'multi' and production_lot_id is not null and cutting_lot_id is null)
  )
);

create unique index if not exists rr_matching_consumption_single_uq
  on public.rr_matching_cloth_consumptions_v1(cutting_lot_id)
  where cutting_lot_id is not null;

create unique index if not exists rr_matching_consumption_multi_uq
  on public.rr_matching_cloth_consumptions_v1(production_lot_id)
  where production_lot_id is not null;

create index if not exists rr_matching_consumption_item_time_idx
  on public.rr_matching_cloth_consumptions_v1(matching_item_id, consumed_at, id);

-- Lot snapshots. Historical values remain unchanged; V4 writes future releases.
alter table public.rr_cutting_lots_v3
  add column if not exists matching_item_id uuid
    references public.rr_matching_cloth_items_v1(id) on delete restrict,
  add column if not exists matching_qty numeric(14,3) not null default 0,
  add column if not exists matching_avg_cost numeric(14,4) not null default 0,
  add column if not exists matching_amount numeric(16,2) not null default 0;

alter table public.rr_production_lots
  add column if not exists matching_item_id uuid
    references public.rr_matching_cloth_items_v1(id) on delete restrict,
  add column if not exists matching_amount numeric(16,2) not null default 0;

-- ---------------------------------------------------------
-- 2. IMPORT EXISTING PRODUCT MASTER MATCHING PURCHASES ONCE
-- ---------------------------------------------------------
insert into public.rr_matching_cloth_items_v1 (fabric_name)
select distinct coalesce(nullif(btrim(pe.fabric_name), ''), 'Matching Cloth')
from public.rr_cb_purchase_entries pe
join public.rr_material_categories mc
  on mc.id = pe.material_category_id
where mc.category_code = 'matching-cloth'
on conflict do nothing;

insert into public.rr_matching_cloth_purchases_v1 (
  matching_item_id,
  vendor_name,
  vendor_bill_no,
  bill_date,
  quantity,
  rate,
  notes,
  source_purchase_entry_id,
  purchased_at
)
select
  item.id,
  pe.vendor_name,
  pe.vendor_bill_no,
  pe.bill_date,
  pe.quantity,
  pe.rate,
  pe.entry_notes,
  pe.id,
  coalesce(pe.created_at, now())
from public.rr_cb_purchase_entries pe
join public.rr_material_categories mc
  on mc.id = pe.material_category_id
join public.rr_matching_cloth_items_v1 item
  on lower(btrim(item.fabric_name)) = lower(btrim(coalesce(nullif(pe.fabric_name, ''), 'Matching Cloth')))
where mc.category_code = 'matching-cloth'
  and pe.quantity > 0
  and pe.rate > 0
on conflict do nothing;

-- Rebuild opening stock from imported/new purchases minus recorded V39 consumption.
update public.rr_matching_cloth_items_v1 item
set stock_qty = greatest(0, coalesce(src.purchase_qty, 0) - coalesce(src.consume_qty, 0)),
    stock_value = greatest(0, round(coalesce(src.purchase_value, 0) - coalesce(src.consume_value, 0), 2)),
    avg_cost = case
      when greatest(0, coalesce(src.purchase_qty, 0) - coalesce(src.consume_qty, 0)) > 0
        then round(
          greatest(0, coalesce(src.purchase_value, 0) - coalesce(src.consume_value, 0))
          / greatest(0, coalesce(src.purchase_qty, 0) - coalesce(src.consume_qty, 0)),
          4
        )
      else 0
    end,
    updated_at = now()
from (
  select
    i.id,
    coalesce(p.qty, 0) as purchase_qty,
    coalesce(p.val, 0) as purchase_value,
    coalesce(c.qty, 0) as consume_qty,
    coalesce(c.val, 0) as consume_value
  from public.rr_matching_cloth_items_v1 i
  left join (
    select matching_item_id, sum(quantity) qty, sum(amount) val
    from public.rr_matching_cloth_purchases_v1
    group by matching_item_id
  ) p on p.matching_item_id = i.id
  left join (
    select matching_item_id, sum(quantity) qty, sum(amount) val
    from public.rr_matching_cloth_consumptions_v1
    group by matching_item_id
  ) c on c.matching_item_id = i.id
) src
where src.id = item.id;

-- ---------------------------------------------------------
-- 3. PRODUCT MASTER PURCHASE RPC + STOCK READER
-- ---------------------------------------------------------
create or replace function public.rr_record_matching_cloth_purchase_v1(
  p_fabric_name text,
  p_vendor_name text,
  p_bill_no text,
  p_bill_date date,
  p_quantity numeric,
  p_rate numeric,
  p_notes text
)
returns uuid
language plpgsql
security definer
set search_path = public
as $function$
declare
  v_name text := btrim(coalesce(p_fabric_name, ''));
  v_item public.rr_matching_cloth_items_v1%rowtype;
  v_purchase_id uuid;
  v_qty numeric(14,3);
  v_rate numeric(14,4);
  v_amount numeric(16,2);
  v_new_qty numeric(14,3);
  v_new_value numeric(16,2);
begin
  if auth.uid() is null then
    raise exception 'Login required';
  end if;

  if to_regprocedure('public.rr_is_owner_or_admin()') is not null
     and not public.rr_is_owner_or_admin() then
    raise exception 'Owner/Admin permission is required' using errcode = '42501';
  end if;

  if v_name = '' then raise exception 'Matching Cloth Fabric Name required'; end if;

  v_qty := round(coalesce(p_quantity, 0)::numeric, 3);
  v_rate := round(coalesce(p_rate, 0)::numeric, 4);

  if v_qty <= 0 then raise exception 'Matching Cloth quantity must be greater than zero'; end if;
  if v_rate <= 0 then raise exception 'Matching Cloth rate must be greater than zero'; end if;

  insert into public.rr_matching_cloth_items_v1(fabric_name)
  values (v_name)
  on conflict do nothing;

  select * into v_item
  from public.rr_matching_cloth_items_v1
  where lower(btrim(fabric_name)) = lower(v_name)
  for update;

  if not found then raise exception 'Matching Cloth stock item could not be created'; end if;

  v_amount := round(v_qty * v_rate, 2);
  v_new_qty := round(v_item.stock_qty + v_qty, 3);
  v_new_value := round(v_item.stock_value + v_amount, 2);

  insert into public.rr_matching_cloth_purchases_v1 (
    matching_item_id, vendor_name, vendor_bill_no, bill_date,
    quantity, rate, notes, purchased_at
  ) values (
    v_item.id,
    nullif(btrim(coalesce(p_vendor_name, '')), ''),
    nullif(btrim(coalesce(p_bill_no, '')), ''),
    coalesce(p_bill_date, current_date),
    v_qty,
    v_rate,
    nullif(btrim(coalesce(p_notes, '')), ''),
    now()
  ) returning id into v_purchase_id;

  update public.rr_matching_cloth_items_v1
  set stock_qty = v_new_qty,
      stock_value = v_new_value,
      avg_cost = case when v_new_qty > 0 then round(v_new_value / v_new_qty, 4) else 0 end,
      is_active = true,
      updated_at = now()
  where id = v_item.id;

  return v_purchase_id;
end;
$function$;

create or replace function public.rr_get_matching_cloth_stock_v1()
returns table (
  matching_item_id uuid,
  fabric_name text,
  available_qty numeric,
  avg_cost numeric,
  stock_value numeric,
  last_purchase_at timestamptz
)
language sql
security definer
set search_path = public
stable
as $function$
  select
    item.id,
    item.fabric_name,
    item.stock_qty,
    item.avg_cost,
    item.stock_value,
    max(p.purchased_at)
  from public.rr_matching_cloth_items_v1 item
  left join public.rr_matching_cloth_purchases_v1 p
    on p.matching_item_id = item.id
  where item.is_active = true
  group by item.id, item.fabric_name, item.stock_qty, item.avg_cost, item.stock_value
  order by item.fabric_name;
$function$;

-- ---------------------------------------------------------
-- 4. SINGLE LOT V4: SERVER MAPS AVG + DEDUCTS STOCK + COST
-- ---------------------------------------------------------
create or replace function public.rr_release_single_lot_v4(
  p_lot_no text,
  p_cb_unit_id uuid,
  p_release_date date,
  p_style_name text,
  p_art_no text,
  p_print_no text,
  p_operator_name text,
  p_size_set text[],
  p_bundle_qty integer,
  p_fabric_used numeric,
  p_wastage_weight numeric,
  p_remnant_weight numeric,
  p_base_cost numeric,
  p_size_type text,
  p_sleeve_type text,
  p_border_type text,
  p_custom_adjustment numeric,
  p_notes text,
  p_breakup jsonb,
  p_matching_item_id uuid,
  p_matching_qty numeric
)
returns uuid
language plpgsql
security definer
set search_path = public
as $function$
declare
  v_item public.rr_matching_cloth_items_v1%rowtype;
  v_lot_id uuid;
  v_qty numeric(14,3) := round(coalesce(p_matching_qty, 0)::numeric, 3);
  v_avg numeric(14,4) := 0;
  v_amount numeric(16,2) := 0;
  v_pcs integer;
begin
  if v_qty < 0 then raise exception 'Matching Cloth Qty cannot be negative'; end if;

  if v_qty > 0 then
    if p_matching_item_id is null then
      raise exception 'Select Matching Cloth stock';
    end if;

    select * into v_item
    from public.rr_matching_cloth_items_v1
    where id = p_matching_item_id and is_active = true
    for update;

    if not found then raise exception 'Matching Cloth stock item not found'; end if;
    if v_item.stock_qty + 0.0005 < v_qty then
      raise exception 'Matching Cloth stock insufficient. Available % kg, required % kg',
        v_item.stock_qty, v_qty;
    end if;

    v_avg := v_item.avg_cost;
    v_amount := round(v_qty * v_avg, 2);
  end if;

  v_lot_id := public.rr_release_single_lot_v3(
    p_lot_no, p_cb_unit_id, p_release_date, p_style_name,
    p_art_no, p_print_no, p_operator_name, p_size_set,
    p_bundle_qty, p_fabric_used, p_wastage_weight,
    p_remnant_weight, p_base_cost, p_size_type,
    p_sleeve_type, p_border_type, p_custom_adjustment,
    p_notes, p_breakup
  );

  select planned_pcs into v_pcs
  from public.rr_cutting_lots_v3
  where id = v_lot_id
  for update;

  update public.rr_cutting_lots_v3
  set matching_item_id = case when v_qty > 0 then p_matching_item_id else null end,
      matching_qty = v_qty,
      matching_avg_cost = v_avg,
      matching_amount = v_amount,
      final_cost_per_piece = round(
        final_cost_per_piece + case when v_pcs > 0 then v_amount / v_pcs else 0 end,
        2
      ),
      total_cutting_cost = round(total_cutting_cost + v_amount, 2)
  where id = v_lot_id;

  if v_qty > 0 then
    insert into public.rr_matching_cloth_consumptions_v1 (
      matching_item_id, cb_unit_id, lot_kind, cutting_lot_id,
      lot_no_snapshot, quantity, avg_cost_snapshot, consumed_at
    ) values (
      p_matching_item_id, p_cb_unit_id, 'single', v_lot_id,
      upper(btrim(p_lot_no)), v_qty, v_avg, now()
    );

    update public.rr_matching_cloth_items_v1
    set stock_qty = round(stock_qty - v_qty, 3),
        stock_value = greatest(0, round(stock_value - v_amount, 2)),
        avg_cost = case
          when round(stock_qty - v_qty, 3) > 0 then v_avg
          else 0
        end,
        updated_at = now()
    where id = p_matching_item_id;
  end if;

  return v_lot_id;
end;
$function$;

-- ---------------------------------------------------------
-- 5. MULTI LOT V4: ALL DEV STOCK VALIDATED IN ONE TRANSACTION
-- ---------------------------------------------------------
create or replace function public.rr_release_multi_lots_v4(
  p_cb_unit_id uuid,
  p_release_date date,
  p_style_name text,
  p_art_no text,
  p_print_no text,
  p_operator_name text,
  p_fabric_used numeric,
  p_wastage_weight numeric,
  p_remnant_weight numeric,
  p_base_cost numeric,
  p_notes text,
  p_lots jsonb
)
returns uuid
language plpgsql
security definer
set search_path = public
as $function$
declare
  v_stock record;
  v_item jsonb;
  v_patched jsonb := '[]'::jsonb;
  v_item_id uuid;
  v_qty numeric(14,3);
  v_avg numeric(14,4);
  v_amount numeric(16,2);
  v_planned integer;
  v_base numeric(14,4);
  v_adjustments numeric(14,4);
  v_final numeric(14,2);
  v_total numeric(16,2);
  v_combo_id uuid;
  v_lot public.rr_production_lots%rowtype;
begin
  if p_lots is null or jsonb_typeof(p_lots) <> 'array' then
    raise exception 'Multi Lot details are required';
  end if;

  -- Lock every selected stock item and validate total requested across all Devs.
  for v_stock in
    select
      (x->>'matching_item_id')::uuid as item_id,
      round(sum(coalesce((x->>'matching_qty')::numeric, 0)), 3) as total_qty
    from jsonb_array_elements(p_lots) x
    where coalesce((x->>'matching_qty')::numeric, 0) > 0
    group by (x->>'matching_item_id')::uuid
    order by (x->>'matching_item_id')::uuid
  loop
    if v_stock.item_id is null then
      raise exception 'Select Matching Cloth stock for every Dev with Matching Qty';
    end if;

    perform 1
    from public.rr_matching_cloth_items_v1
    where id = v_stock.item_id and is_active = true
    for update;

    if not found then
      raise exception 'Matching Cloth stock item not found';
    end if;

    select stock_qty into v_qty
    from public.rr_matching_cloth_items_v1
    where id = v_stock.item_id;

    if v_qty + 0.0005 < v_stock.total_qty then
      raise exception 'Matching Cloth stock insufficient. Available % kg, required % kg',
        v_qty, v_stock.total_qty;
    end if;
  end loop;

  -- Force the server-side average and exact cost into each Dev payload.
  for v_item in
    select value from jsonb_array_elements(p_lots)
  loop
    v_qty := round(coalesce((v_item->>'matching_qty')::numeric, 0), 3);
    v_planned := coalesce((v_item->>'cutting_pcs')::integer, 0);
    v_avg := 0;
    v_amount := 0;

    if v_qty > 0 then
      v_item_id := (v_item->>'matching_item_id')::uuid;
      select avg_cost into v_avg
      from public.rr_matching_cloth_items_v1
      where id = v_item_id;
      v_amount := round(v_qty * v_avg, 2);
    else
      v_item_id := null;
    end if;

    v_base := round(coalesce((v_item->>'base_cost')::numeric, p_base_cost, 0), 4);
    v_adjustments :=
      round(coalesce((v_item->>'size_adjustment')::numeric, 0), 4)
      + round(coalesce((v_item->>'sleeve_adjustment')::numeric, 0), 4)
      + round(coalesce((v_item->>'border_adjustment')::numeric, 0), 4)
      + round(coalesce((v_item->>'custom_adjustment')::numeric, 0), 4);

    v_final := round(
      v_base + v_adjustments
      + case when v_planned > 0 then v_amount / v_planned else 0 end,
      2
    );
    v_total := round((v_base + v_adjustments) * v_planned + v_amount, 2);

    v_item := jsonb_set(v_item, '{matching_avg_cost}', to_jsonb(v_avg), true);
    v_item := jsonb_set(v_item, '{final_cost_per_piece}', to_jsonb(v_final), true);
    v_item := jsonb_set(v_item, '{total_cutting_cost}', to_jsonb(v_total), true);
    v_patched := v_patched || jsonb_build_array(v_item);
  end loop;

  v_combo_id := public.rr_release_multi_lots_v3(
    p_cb_unit_id, p_release_date, p_style_name, p_art_no, p_print_no,
    p_operator_name, p_fabric_used, p_wastage_weight, p_remnant_weight,
    p_base_cost, p_notes, v_patched
  );

  -- Snapshot and deduct each Dev after V3 creates the Production Lots.
  for v_item in
    select value from jsonb_array_elements(v_patched)
  loop
    v_qty := round(coalesce((v_item->>'matching_qty')::numeric, 0), 3);
    if v_qty <= 0 then continue; end if;

    v_item_id := (v_item->>'matching_item_id')::uuid;
    v_avg := round(coalesce((v_item->>'matching_avg_cost')::numeric, 0), 4);
    v_amount := round(v_qty * v_avg, 2);

    select * into v_lot
    from public.rr_production_lots
    where cb_unit_id = p_cb_unit_id
      and lower(btrim(lot_no)) = lower(btrim(v_item->>'lot_no'))
    for update;

    if not found then raise exception 'Created Multi Lot could not be mapped'; end if;

    update public.rr_production_lots
    set matching_item_id = v_item_id,
        matching_avg_cost = v_avg,
        matching_amount = v_amount
    where id = v_lot.id;

    insert into public.rr_matching_cloth_consumptions_v1 (
      matching_item_id, cb_unit_id, lot_kind, production_lot_id,
      lot_no_snapshot, quantity, avg_cost_snapshot, consumed_at
    ) values (
      v_item_id, p_cb_unit_id, 'multi', v_lot.id,
      v_lot.lot_no, v_qty, v_avg, now()
    );

    update public.rr_matching_cloth_items_v1
    set stock_qty = round(stock_qty - v_qty, 3),
        stock_value = greatest(0, round(stock_value - v_amount, 2)),
        avg_cost = case when round(stock_qty - v_qty, 3) > 0 then v_avg else 0 end,
        updated_at = now()
    where id = v_item_id;
  end loop;

  return v_combo_id;
end;
$function$;

-- ---------------------------------------------------------
-- 5B. AUTO-SYNC PRODUCT MASTER MATCHING PURCHASES
-- ---------------------------------------------------------
create or replace function public.rr_rebuild_matching_item_v1(p_item_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $function$
declare
  v_purchase_qty numeric(14,3) := 0;
  v_purchase_value numeric(16,2) := 0;
  v_consume_qty numeric(14,3) := 0;
  v_consume_value numeric(16,2) := 0;
  v_balance_qty numeric(14,3) := 0;
  v_balance_value numeric(16,2) := 0;
begin
  select coalesce(sum(quantity),0), coalesce(sum(amount),0)
    into v_purchase_qty, v_purchase_value
  from public.rr_matching_cloth_purchases_v1
  where matching_item_id = p_item_id;

  select coalesce(sum(quantity),0), coalesce(sum(amount),0)
    into v_consume_qty, v_consume_value
  from public.rr_matching_cloth_consumptions_v1
  where matching_item_id = p_item_id;

  v_balance_qty := greatest(0, round(v_purchase_qty - v_consume_qty, 3));
  v_balance_value := greatest(0, round(v_purchase_value - v_consume_value, 2));

  update public.rr_matching_cloth_items_v1
  set stock_qty = v_balance_qty,
      stock_value = v_balance_value,
      avg_cost = case
        when v_balance_qty > 0 then round(v_balance_value / v_balance_qty, 4)
        else 0
      end,
      updated_at = now()
  where id = p_item_id;
end;
$function$;

create or replace function public.rr_sync_matching_purchase_entry_v1()
returns trigger
language plpgsql
security definer
set search_path = public
as $function$
declare
  v_is_matching boolean := false;
  v_item_id uuid;
  v_old_item_id uuid;
  v_name text;
begin
  if tg_op in ('UPDATE','DELETE') then
    select p.matching_item_id
      into v_old_item_id
    from public.rr_matching_cloth_purchases_v1 p
    where p.source_purchase_entry_id = old.id;
  end if;

  if tg_op in ('INSERT','UPDATE') then
    select exists (
      select 1
      from public.rr_material_categories mc
      where mc.id = new.material_category_id
        and mc.category_code = 'matching-cloth'
    ) into v_is_matching;

    if v_is_matching then
      v_name := coalesce(nullif(btrim(new.fabric_name), ''), 'Matching Cloth');

      insert into public.rr_matching_cloth_items_v1(fabric_name)
      values (v_name)
      on conflict ((lower(btrim(fabric_name)))) do update
      set fabric_name = excluded.fabric_name,
          is_active = true,
          updated_at = now()
      returning id into v_item_id;

      insert into public.rr_matching_cloth_purchases_v1(
        matching_item_id, vendor_name, vendor_bill_no, bill_date,
        quantity, rate, notes, source_purchase_entry_id, purchased_at
      ) values (
        v_item_id, new.vendor_name, new.vendor_bill_no, new.bill_date,
        new.quantity, new.rate, new.entry_notes, new.id,
        coalesce(new.created_at, now())
      )
      on conflict (source_purchase_entry_id) where source_purchase_entry_id is not null
      do update set
        matching_item_id = excluded.matching_item_id,
        vendor_name = excluded.vendor_name,
        vendor_bill_no = excluded.vendor_bill_no,
        bill_date = excluded.bill_date,
        quantity = excluded.quantity,
        rate = excluded.rate,
        notes = excluded.notes;
    else
      delete from public.rr_matching_cloth_purchases_v1
      where source_purchase_entry_id = new.id;
    end if;
  else
    delete from public.rr_matching_cloth_purchases_v1
    where source_purchase_entry_id = old.id;
  end if;

  if v_old_item_id is not null then
    perform public.rr_rebuild_matching_item_v1(v_old_item_id);
  end if;

  if v_item_id is not null and v_item_id is distinct from v_old_item_id then
    perform public.rr_rebuild_matching_item_v1(v_item_id);
  end if;

  return coalesce(new, old);
end;
$function$;

drop trigger if exists rr_sync_matching_purchase_entry_v1
  on public.rr_cb_purchase_entries;

create trigger rr_sync_matching_purchase_entry_v1
after insert or update or delete on public.rr_cb_purchase_entries
for each row execute function public.rr_sync_matching_purchase_entry_v1();

-- Re-sync all existing matching entries safely after trigger installation.
insert into public.rr_matching_cloth_purchases_v1 (
  matching_item_id, vendor_name, vendor_bill_no, bill_date,
  quantity, rate, notes, source_purchase_entry_id, purchased_at
)
select
  item.id, pe.vendor_name, pe.vendor_bill_no, pe.bill_date,
  pe.quantity, pe.rate, pe.entry_notes, pe.id, coalesce(pe.created_at, now())
from public.rr_cb_purchase_entries pe
join public.rr_material_categories mc
  on mc.id = pe.material_category_id and mc.category_code = 'matching-cloth'
join public.rr_matching_cloth_items_v1 item
  on lower(btrim(item.fabric_name)) = lower(btrim(coalesce(nullif(pe.fabric_name,''),'Matching Cloth')))
where pe.quantity > 0 and pe.rate > 0
on conflict (source_purchase_entry_id) where source_purchase_entry_id is not null
do update set
  matching_item_id = excluded.matching_item_id,
  vendor_name = excluded.vendor_name,
  vendor_bill_no = excluded.vendor_bill_no,
  bill_date = excluded.bill_date,
  quantity = excluded.quantity,
  rate = excluded.rate,
  notes = excluded.notes;

do $rebuild$
declare r record;
begin
  for r in select id from public.rr_matching_cloth_items_v1 loop
    perform public.rr_rebuild_matching_item_v1(r.id);
  end loop;
end
$rebuild$;

-- ---------------------------------------------------------
-- 6. PERMISSIONS
-- ---------------------------------------------------------
revoke all on function public.rr_record_matching_cloth_purchase_v1(text,text,text,date,numeric,numeric,text) from public;
revoke all on function public.rr_get_matching_cloth_stock_v1() from public;
revoke all on function public.rr_release_single_lot_v4(text,uuid,date,text,text,text,text,text[],integer,numeric,numeric,numeric,numeric,text,text,text,numeric,text,jsonb,uuid,numeric) from public;
revoke all on function public.rr_release_multi_lots_v4(uuid,date,text,text,text,text,numeric,numeric,numeric,numeric,text,jsonb) from public;

grant execute on function public.rr_record_matching_cloth_purchase_v1(text,text,text,date,numeric,numeric,text) to authenticated;
grant execute on function public.rr_get_matching_cloth_stock_v1() to authenticated;
grant execute on function public.rr_release_single_lot_v4(text,uuid,date,text,text,text,text,text[],integer,numeric,numeric,numeric,numeric,text,text,text,numeric,text,jsonb,uuid,numeric) to authenticated;
grant execute on function public.rr_release_multi_lots_v4(uuid,date,text,text,text,text,numeric,numeric,numeric,numeric,text,jsonb) to authenticated;

grant select on public.rr_matching_cloth_items_v1 to authenticated;
grant select on public.rr_matching_cloth_purchases_v1 to authenticated;
grant select on public.rr_matching_cloth_consumptions_v1 to authenticated;

commit;
